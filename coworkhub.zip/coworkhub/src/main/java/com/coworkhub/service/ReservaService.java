package com.coworkhub.service;

import com.coworkhub.model.*;
import com.coworkhub.repository.ReservaRepository;
import com.coworkhub.repository.EspacioRepository;
import com.coworkhub.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository reservaRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EspacioRepository espacioRepository;

    public List<Reserva> obtenerReservasActivas() {
        return reservaRepository.findByEstado(EstadoReserva.ACTIVA);
    }

    public List<Reserva> obtenerHistorial() {
        return reservaRepository.findHistorialByEstado(EstadoReserva.CANCELADA);
    }

    public List<Reserva> obtenerReservasPorUsuario(User usuario) {
        return reservaRepository.findByUsuarioAndEstado(usuario, EstadoReserva.ACTIVA);
    }

    public void guardarReserva(Reserva reserva) {
        reserva.setFechaReserva(LocalDateTime.now());
        reserva.setEstado(EstadoReserva.ACTIVA);
        reservaRepository.save(reserva);
    }

    // Otras validaciones, solapamiento, etc., van aquí
}

