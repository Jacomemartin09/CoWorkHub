package com.coworkhub.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.coworkhub.model.Role;
import com.coworkhub.model.User;
import com.coworkhub.repository.RoleRepository;
import com.coworkhub.repository.UserRepository;

@Controller
public class ViewController {

    private final UserRepository userRepository;
   
    @Autowired
    private RoleRepository roleRepository;

    public ViewController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/home")
    public String home(Model model, Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        String email = authentication.getName();
        User user = userRepository.findByEmail(email).orElse(null);

        if (user == null) {
            return "redirect:/login?error=true";
        }

        model.addAttribute("user", user);
        return "home";
    }

	@GetMapping("/login")
	public String showLoginPage() {
		return "authentication-login"; // busca login.html en /templates
	}

	@GetMapping("/")
	public String redirectToLogin() {
		return "redirect:/login";
	}

	
	
	

}
