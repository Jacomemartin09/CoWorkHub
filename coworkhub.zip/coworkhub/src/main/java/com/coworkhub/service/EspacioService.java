package com.coworkhub.service;

import com.coworkhub.model.Espacio;
import com.coworkhub.repository.EspacioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EspacioService {

    @Autowired
    private EspacioRepository espacioRepository;

    public List<Espacio> listarTodos() {
        return espacioRepository.findAll();
    }

    public void guardar(Espacio espacio) {
        espacioRepository.save(espacio);
    }

    public Optional<Espacio> obtenerPorId(Long id) {
        return espacioRepository.findById(id);
    }

    public void eliminar(Long id) {
        espacioRepository.deleteById(id);
    }
}
