package com.coworkhub.service;

import com.coworkhub.model.Role;
import com.coworkhub.model.User;
import com.coworkhub.repository.RoleRepository;
import com.coworkhub.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Collections;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void saveUser(User user, String roleName) {

        System.out.println("Rol recibido: " + roleName);
        System.out.println("Usuario recibido: " + user.getEmail());
        System.out.println("→ Guardando usuario con rol: " + roleName);

        // Encriptar la contraseña antes de guardar
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Buscar el rol por nombre
        Role role = roleRepository.findByName(roleName);
        if (role == null) {
            throw new RuntimeException("No se encontró el rol: " + roleName);
        }

        // Asignar el rol al usuario
        user.setRoles(Collections.singleton(role));

        // Guardar en la base de datos
        userRepository.save(user);

        System.out.println("✔ Usuario guardado correctamente: " + user.getEmail());
    }

    // ✅ Nuevo método para obtener al usuario autenticado
    public User getUsuarioAutenticado() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String email;

        if (principal instanceof UserDetails) {
            email = ((UserDetails) principal).getUsername(); // En Spring Security se usa `username` para el email
        } else {
            email = principal.toString();
        }

        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado con email: " + email));
    }
}
