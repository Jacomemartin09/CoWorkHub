package com.coworkhub.model;

public enum TipoReserva {
    POR_HORA,
    POR_DIA
}