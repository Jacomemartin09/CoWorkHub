package com.coworkhub.controller;

import com.coworkhub.model.*;
import com.coworkhub.repository.EspacioRepository;
import com.coworkhub.repository.ReservaRepository;
import com.coworkhub.repository.UserRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/reservas")
@RequiredArgsConstructor
public class ReservaController {

    private final ReservaRepository reservaRepository;
    private final EspacioRepository espacioRepository;
    private final UserRepository userRepository;

    @GetMapping("/nueva")
    public String mostrarFormularioReserva(Model model, Authentication authentication) {
        String email = authentication.getName();
        User usuario = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con el correo: " + email));

        model.addAttribute("espacios", espacioRepository.findAll());
        model.addAttribute("reserva", new Reserva());
        return "reservas/formulario";
    }

    @GetMapping("/admin/nueva")
    public String mostrarFormularioAdmin(Model model) {
        model.addAttribute("espacios", espacioRepository.findAll());
        model.addAttribute("usuarios", userRepository.findAll());
        model.addAttribute("reserva", new Reserva());
        return "reservas/formulario-admin";
    }

    @PostMapping("/crear")
    public String procesarReserva(@ModelAttribute @Valid Reserva reserva,
                                  BindingResult result,
                                  @RequestParam Long espacioId,
                                  @RequestParam(required = false) Long usuarioId,
                                  @RequestParam String fechaInicio,
                                  @RequestParam String horaInicio,
                                  @RequestParam String fechaFin,
                                  @RequestParam String horaFin,
                                  Authentication authentication,
                                  Model model) {
        if (result.hasErrors()) {
            model.addAttribute("espacios", espacioRepository.findAll());
            if (usuarioId != null) {
                model.addAttribute("usuarios", userRepository.findAll());
            }
            return usuarioId != null ? "reservas/formulario-admin" : "reservas/formulario";
        }

        Espacio espacio = espacioRepository.findById(espacioId)
                .orElseThrow(() -> new RuntimeException("Espacio no encontrado"));

        User usuario;
        if (usuarioId != null) {
            usuario = userRepository.findById(usuarioId)
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado por ID"));
        } else {
            String email = authentication.getName();
            usuario = userRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Usuario no encontrado por correo"));
        }

        LocalDateTime inicio = LocalDateTime.of(LocalDate.parse(fechaInicio), LocalTime.parse(horaInicio));
        LocalDateTime fin = LocalDateTime.of(LocalDate.parse(fechaFin), LocalTime.parse(horaFin));

        if (reserva.getTipoReserva() == TipoReserva.POR_HORA && (inicio.getMinute() != 0 || fin.getMinute() != 0)) {
            result.rejectValue("fechaHoraInicio", "error.reserva", "Las horas deben ser exactas, sin minutos.");
            model.addAttribute("espacios", espacioRepository.findAll());
            if (usuarioId != null) {
                model.addAttribute("usuarios", userRepository.findAll());
            }
            return usuarioId != null ? "reservas/formulario-admin" : "reservas/formulario";
        }

        double precioTotal;
        if (reserva.getTipoReserva() == TipoReserva.POR_HORA) {
            long horas = java.time.Duration.between(inicio, fin).toHours();
            precioTotal = espacio.getPrecioPorHora() * horas;
        } else {
            long dias = java.time.Duration.between(inicio, fin).toDays();
            precioTotal = espacio.getPrecioPorDia() * (dias == 0 ? 1 : dias);
        }

        reserva.setFechaHoraInicio(inicio);
        reserva.setFechaHoraFin(fin);
        reserva.setEspacio(espacio);
        reserva.setUsuario(usuario);
        reserva.setFechaReserva(LocalDateTime.now());
        reserva.setEstado(EstadoReserva.ACTIVA);
        reserva.setPrecioTotal(precioTotal);

        reservaRepository.save(reserva);

        return usuarioId != null ? "redirect:/reservas/activas" : "redirect:/reservas/mis-reservas";
    }

    @GetMapping("/mis-reservas")
    public String verReservasCliente(Model model, Authentication authentication) {
        String email = authentication.getName();
        User usuario = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        List<Reserva> reservas = reservaRepository.findByUsuario(usuario);
        model.addAttribute("reservas", reservas);
        return "reservas/mis-reservas";
    }

    @GetMapping("/activas")
    public String verReservasActivas(Model model) {
        List<Reserva> reservas = reservaRepository.findByEstado(EstadoReserva.ACTIVA);
        model.addAttribute("reservas", reservas);
        model.addAttribute("usuarios", userRepository.findAll());
        return "reservas/activas";
    }

    @GetMapping("/historial")
    public String verHistorialReservas(Model model,
                                       @RequestParam(required = false) Long clienteId,
                                       @RequestParam(required = false) String estado) {
        List<Reserva> reservas = reservaRepository.findAll();

        LocalDateTime ahora = LocalDateTime.now();
        for (Reserva r : reservas) {
            if (r.getEstado() == EstadoReserva.ACTIVA && r.getFechaHoraFin().isBefore(ahora)) {
                r.setEstado(EstadoReserva.CADUCADA);
                reservaRepository.save(r);
            }
        }

        reservas = reservas.stream()
                .filter(r -> r.getEstado() != EstadoReserva.ACTIVA)
                .filter(r -> clienteId == null || r.getUsuario().getId().equals(clienteId))
                .filter(r -> estado == null || estado.isEmpty() || r.getEstado().name().equalsIgnoreCase(estado))
                .collect(Collectors.toList());

        model.addAttribute("reservas", reservas);
        model.addAttribute("usuarios", userRepository.findAll());
        model.addAttribute("clienteId", clienteId);
        model.addAttribute("estado", estado);

        return "reservas/historial";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
        Reserva reserva = reservaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Reserva no encontrada"));
        model.addAttribute("reserva", reserva);
        model.addAttribute("espacios", espacioRepository.findAll());
        model.addAttribute("usuarios", userRepository.findAll());
        return "reservas/editar";
    }

    @PostMapping("/actualizar")
    public String actualizarReserva(@ModelAttribute Reserva reserva) {
        reserva.setFechaReserva(LocalDateTime.now());
        reservaRepository.save(reserva);
        return "redirect:/reservas/activas";
    }

    @GetMapping("/cancelar/{id}")
    public String cancelarReserva(@PathVariable Long id) {
        Reserva reserva = reservaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Reserva no encontrada"));
        reserva.setEstado(EstadoReserva.CANCELADA);
        reservaRepository.save(reserva);
        return "redirect:/reservas/activas";
    }
}



