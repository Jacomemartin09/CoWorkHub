package com.coworkhub.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fechaHoraInicio;

    private LocalDateTime fechaHoraFin;

    private LocalDateTime fechaReserva;

    private double precioTotal;

    @Enumerated(EnumType.STRING)
    private TipoReserva tipoReserva;

    @Enumerated(EnumType.STRING)
    private EstadoReserva estado;

    @ManyToOne
    private Espacio espacio;

    @ManyToOne
    private User usuario;
}

