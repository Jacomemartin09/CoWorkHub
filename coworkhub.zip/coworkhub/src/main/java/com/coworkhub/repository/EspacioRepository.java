package com.coworkhub.repository;

import com.coworkhub.model.Espacio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EspacioRepository extends JpaRepository<Espacio, Long> {
}
