package com.coworkhub.model;

public enum EstadoReserva {
    ACTIVA,
    CANCELADA, CADUCADA
}
