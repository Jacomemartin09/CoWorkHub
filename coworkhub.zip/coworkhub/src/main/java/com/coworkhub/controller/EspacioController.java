package com.coworkhub.controller;

import com.coworkhub.model.Espacio;
import com.coworkhub.service.EspacioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/espacios")
public class EspacioController {

    @Autowired
    private EspacioService espacioService;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("espacios", espacioService.listarTodos());
        return "espacios";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("espacio", new Espacio());
        return "espacio-form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("espacio") Espacio espacio, BindingResult result) {
        if (result.hasErrors()) {
            return "espacio-form";
        }
        espacioService.guardar(espacio);
        return "redirect:/espacios";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        espacioService.obtenerPorId(id).ifPresent(espacio -> model.addAttribute("espacio", espacio));
        return "espacio-form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        espacioService.eliminar(id); // En el futuro se debe validar que no tenga reservas
        return "redirect:/espacios";
    }
}
