package com.coworkhub.repository;

import com.coworkhub.model.Reserva;
import com.coworkhub.model.Espacio;
import com.coworkhub.model.EstadoReserva;
import com.coworkhub.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva, Long> {

	List<Reserva> findByEstado(com.coworkhub.model.EstadoReserva estado); // Para admin: reservas activas

	List<Reserva> findByUsuario(User usuario); // Para cliente: ver sus reservas

	List<Reserva> findByUsuarioAndEstado(User usuario, com.coworkhub.model.EstadoReserva estado); // Activas por cliente

	@Query("SELECT r FROM Reserva r WHERE r.estado = :estado ORDER BY r.fechaReserva DESC")
	List<Reserva> findHistorialByEstado(@Param("estado") com.coworkhub.model.EstadoReserva estado);
	
	List<Reserva> findByEstadoNot(EstadoReserva estado);


}
