package com.coworkhub.controller;

import com.coworkhub.model.Role;
import com.coworkhub.model.User;
import com.coworkhub.repository.RoleRepository;
import com.coworkhub.repository.UserRepository;
import com.coworkhub.service.UserService;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private UserService userService;

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		model.addAttribute("roles", roleRepository.findAll());
		return "usuario-form";
	}

	@PostMapping("/register")
	public String registerUser(@ModelAttribute("user") User user, @RequestParam("rol") String rolNombre) {
		userService.saveUser(user, rolNombre);
		return "redirect:/login?success";
	}

	// Métodos API REST opcionales
	@GetMapping("/api/users")
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@PostMapping("/api/users")
	public ResponseEntity<?> createUser(@Valid @RequestBody User user) {
		if (userRepository.findByEmail(user.getEmail()).isPresent()) {
			return ResponseEntity.badRequest().body("❌ Ya existe un usuario con ese correo electrónico.");
		}
		return ResponseEntity.ok(userRepository.save(user));
	}

	@DeleteMapping("/api/users/{id}")
	public void deleteUser(@PathVariable Long id) {
		userRepository.deleteById(id);
	}

	@GetMapping("/api/users/{id}")
	public User getUserById(@PathVariable Long id) {
		return userRepository.findById(id).orElse(null);
	}
	
	@GetMapping("/usuarios")
	@Secured("ROLE_ADMIN")
	public String listarUsuarios(Model model) {
	    List<User> usuarios = userRepository.findAll();
	    model.addAttribute("usuarios", usuarios);
	    return "usuarios";
	}
	
	@GetMapping("/usuarios/nuevo")
	@Secured("ROLE_ADMIN")
	public String mostrarFormularioUsuario(Model model) {
	    model.addAttribute("usuario", new User());
	    model.addAttribute("roles", roleRepository.findAll());
	    return "usuario-form";
	}

	@PostMapping("/usuarios/guardar")
	@Secured("ROLE_ADMIN")
	public String guardarUsuario(@ModelAttribute("usuario") User user, @RequestParam("rol") String rolNombre) {
	    userService.saveUser(user, rolNombre); // Usa el servicio existente que encripta y asigna rol
	    return "redirect:/usuarios";
	}
	
	@GetMapping("/usuarios/editar/{id}")
	@Secured("ROLE_ADMIN")
	public String editarUsuario(@PathVariable Long id, Model model) {
	    User usuario = userRepository.findById(id)
	        .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + id));
	    
	    model.addAttribute("usuario", usuario);
	    model.addAttribute("roles", roleRepository.findAll());

	    return "usuario-form";
	}
	
	@GetMapping("/usuarios/eliminar/{id}")
	@Secured("ROLE_ADMIN")
	public String eliminarUsuario(@PathVariable Long id) {
	    userRepository.deleteById(id);
	    return "redirect:/usuarios?eliminado=true";
	}


}
